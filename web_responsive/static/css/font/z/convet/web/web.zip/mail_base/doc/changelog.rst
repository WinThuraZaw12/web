`1.0.4`
-------
**FIX**: issue related to clear cache

`1.0.3`
-------
**FIX**: error on clicking messages preview after sending new message

`1.0.2`
-------

- **FIX**: fixed an error with unsubscribing from channel or closing dialog window

`1.0.1`
-------

- **FIX**: clear messages cache on sending message via Mail Composer. Otherwise Sent, Arhives menus will have new message until user refresh whole web page

`1.0.0`
-------

- Init version

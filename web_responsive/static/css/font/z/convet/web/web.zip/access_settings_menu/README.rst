Show settings menu for non-admin
================================

Adds "Show Settings Menu" tick in user's access rights tab.

Uninstallation
--------------

After uninstalling, you need to update ``base`` module to return restriction to ``Settings`` menu back.

Tested on 12.0 b34b7d4270eda98ee8e87516c044161232b335ae

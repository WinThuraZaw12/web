=========================
 Mail Base
=========================

Installation
============

* `Install <https://odoo-development.readthedocs.io/en/latest/odoo/usage/install-module.html>`__ this module in a usual way

Configuration
=============

This module does not require special configuration.

Usage
=====

* To use this module you need either install module that depends on it or create new module.

# License LGPL-3.0 or later (http://www.gnu.org/licenses/lgpl.html).

from . import ir_actions
from . import ir_translation
from . import publisher_warranty_contract
from . import ir_config_parameter
from . import ir_ui_view
from . import mail_message
from . import mail_channel
from . import res_users
